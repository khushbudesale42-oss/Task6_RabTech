"""Download the public SMS Spam Collection and train the champion model."""
from pathlib import Path
import io
import zipfile
import urllib.request

import joblib
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report

DATA_URL = "https://archive.ics.uci.edu/static/public/228/sms+spam+collection.zip"
ROOT = Path(__file__).resolve().parent
ARTIFACT_DIR = ROOT / "artifacts"
MODEL_PATH = ARTIFACT_DIR / "champion_model.joblib"


def load_dataset():
    request = urllib.request.Request(DATA_URL, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(request, timeout=60) as response:
        archive_bytes = response.read()
    with zipfile.ZipFile(io.BytesIO(archive_bytes)) as archive:
        data_name = next(name for name in archive.namelist() if name.endswith("SMSSpamCollection"))
        with archive.open(data_name) as data_file:
            df = pd.read_csv(data_file, sep="\t", header=None, names=["label", "text"], encoding="utf-8")
    df = df.dropna(subset=["label", "text"]).drop_duplicates(subset=["text"])
    df["label"] = df["label"].str.strip().str.lower()
    df = df[df["label"].isin(["ham", "spam"])]
    return df


def main():
    print("Downloading SMS Spam Collection dataset...")
    df = load_dataset()
    X_train, X_test, y_train, y_test = train_test_split(
        df["text"], df["label"], test_size=0.2, random_state=42, stratify=df["label"]
    )
    model = Pipeline([
        ("tfidf", TfidfVectorizer(lowercase=True, strip_accents="unicode", ngram_range=(1, 2),
                                  max_features=30000, sublinear_tf=True)),
        ("classifier", LogisticRegression(max_iter=1000, class_weight="balanced", random_state=42)),
    ])
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)
    print(f"Dataset rows: {len(df)}")
    print(f"Test accuracy: {accuracy_score(y_test, predictions):.4f}")
    print(classification_report(y_test, predictions, zero_division=0))
    ARTIFACT_DIR.mkdir(parents=True, exist_ok=True)
    joblib.dump(model, MODEL_PATH)
    print(f"Saved model to: {MODEL_PATH}")


if __name__ == "__main__":
    main()
