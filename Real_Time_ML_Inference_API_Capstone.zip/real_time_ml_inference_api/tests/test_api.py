import joblib
import pytest
from fastapi.testclient import TestClient
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline

from app import main


@pytest.fixture()
def client_with_temporary_model(tmp_path, monkeypatch):
    # Tiny deterministic fixture model keeps unit tests independent of internet access.
    texts = [
        "win a free prize now", "claim your cash reward", "urgent winner call now",
        "hello how are you", "are we meeting today", "please send the class notes",
        "free entry prize winner", "hey see you tomorrow", "thanks for your message",
        "cash offer click now",
    ]
    labels = ["spam", "spam", "spam", "ham", "ham", "ham", "spam", "ham", "ham", "spam"]
    model = Pipeline([
        ("tfidf", TfidfVectorizer()),
        ("classifier", LogisticRegression(random_state=42)),
    ])
    model.fit(texts, labels)
    model_path = tmp_path / "champion_model.joblib"
    joblib.dump(model, model_path)

    monkeypatch.setattr(main, "MODEL_PATH", model_path)
    monkeypatch.setattr(main, "_model", None)
    return TestClient(main.app)


def test_root(client_with_temporary_model):
    response = client_with_temporary_model.get("/")
    assert response.status_code == 200
    assert response.json()["docs"] == "/docs"


def test_health(client_with_temporary_model):
    response = client_with_temporary_model.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"


def test_predict_returns_probabilities(client_with_temporary_model):
    response = client_with_temporary_model.post(
        "/predict", json={"text": "Congratulations, you won a free prize"}
    )
    assert response.status_code == 200
    body = response.json()
    assert body["prediction"] in ["Spam", "Not Spam"]
    assert set(body["probabilities"]) == {"not_spam", "spam"}
    assert abs(sum(body["probabilities"].values()) - 1.0) < 0.001
    assert body["model_version"]


def test_empty_text_rejected(client_with_temporary_model):
    response = client_with_temporary_model.post("/predict", json={"text": "   "})
    assert response.status_code == 422


def test_missing_text_rejected(client_with_temporary_model):
    response = client_with_temporary_model.post("/predict", json={})
    assert response.status_code == 422
