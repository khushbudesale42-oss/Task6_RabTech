from pathlib import Path
from typing import Dict

import joblib
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

BASE_DIR = Path(__file__).resolve().parent.parent
MODEL_PATH = BASE_DIR / "artifacts" / "champion_model.joblib"

app = FastAPI(
    title="Real-Time ML Inference API",
    description="REST API for classifying a message as spam or not spam.",
    version="1.0.0",
)

_model = None


class PredictRequest(BaseModel):
    text: str = Field(..., min_length=1, max_length=10000, description="Message to classify")


class PredictResponse(BaseModel):
    prediction: str
    probabilities: Dict[str, float]
    model_version: str


def load_model():
    global _model
    if _model is None:
        if not MODEL_PATH.exists():
            raise RuntimeError(
                "Model artifact not found. Run `python train_model.py` before starting the API."
            )
        _model = joblib.load(MODEL_PATH)
    return _model


@app.get("/")
def root():
    return {
        "message": "Real-Time ML Inference API",
        "docs": "/docs",
        "health": "/health",
    }


@app.get("/health")
def health():
    model_ready = MODEL_PATH.exists() or _model is not None
    return {"status": "ok" if model_ready else "model_not_ready", "model_loaded": _model is not None}


@app.post("/predict", response_model=PredictResponse)
def predict(request: PredictRequest):
    text = request.text.strip()
    if not text:
        raise HTTPException(status_code=422, detail="text must not be blank")

    try:
        model = load_model()
        probs = model.predict_proba([text])[0]
        classes = list(model.classes_)
        probability_map = {str(label): round(float(prob), 6) for label, prob in zip(classes, probs)}
        predicted_class = str(model.predict([text])[0])
        # Dataset labels are normalized to "ham" and "spam".
        label = "Spam" if predicted_class == "spam" else "Not Spam"
        return PredictResponse(
            prediction=label,
            probabilities={
                "not_spam": probability_map.get("ham", 0.0),
                "spam": probability_map.get("spam", 0.0),
            },
            model_version="tfidf-logistic-regression-v1",
        )
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
